import java.util.*;

public class Board {
  // 6 rows, 7 col
  public static char[][]board = new char[6][7]; 
}